function y = oct_01(x)
   y = x;
end
% --- last line ---
