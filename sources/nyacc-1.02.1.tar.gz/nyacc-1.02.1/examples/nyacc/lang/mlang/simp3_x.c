// simp3.m - a simple demo file
double simp3(double a, double b);
static double inv(double x);

// SIMP3 - illustrate basic function in mlang
// a: scalar
// b: scalar
// c: returned scalar sum
double simp3(double a, double b) {
  double c;
  
  // Just do something simple.
  c = a + b;
  return c;
}
