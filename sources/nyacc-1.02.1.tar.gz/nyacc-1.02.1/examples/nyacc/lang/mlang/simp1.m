function c = simp1(a, b)
  c = a + b
end
