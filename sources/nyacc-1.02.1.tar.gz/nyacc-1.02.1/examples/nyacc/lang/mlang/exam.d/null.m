function null()
% NULL -
