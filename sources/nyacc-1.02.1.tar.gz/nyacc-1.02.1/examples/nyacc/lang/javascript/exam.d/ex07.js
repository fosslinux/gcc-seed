var x = 0;
do { 
  x = x + 1;
  if (x > 2) break;
  display(x); newline();
} while (x < 4);
while (x > 0) {
  display(x); newline();
  x = x - 1;
} 
