// inc/fh01.h

typedef struct foo *bar_t;

struct foo {
  int a;
};

