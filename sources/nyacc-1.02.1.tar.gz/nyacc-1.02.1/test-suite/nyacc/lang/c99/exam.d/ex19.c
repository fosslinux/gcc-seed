
int bar(int x) {
  typedef int foo_t;
  foo_t y = 1;
  return x + y;
}

int baz(int x) {
  typedef int foo_t;
  foo_t y = 1;
  return x + y;
}

