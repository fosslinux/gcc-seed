#define __builtin_va_list void*
#define __DARWIN_ALIAS(X) /* */
#include "inc.h"
