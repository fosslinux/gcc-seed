// lex
int x; \
int y;
