#ifndef ABC
#include "ex14.h"
#define ABC
#endif

#ifdef ABC
eval_t x;
#endif

/* used by c99-04.test */
