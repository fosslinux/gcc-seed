char int i;
